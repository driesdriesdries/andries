<div class="logo-container">
    <div class="logo-container__logo logo-container__logo--1"></div>
    <div class="logo-container__logo logo-container__logo--2"></div>
    <div class="logo-container__logo logo-container__logo--3"></div>
    <div class="logo-container__logo logo-container__logo--4"></div>
</div>