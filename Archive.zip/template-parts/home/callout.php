<div class="callout fade-in">
    
    <div class="button-group">
        <a class="base-button primary-button contact-button" href="#">Get In Touch</a>
        <a class="base-button secondary-button" href="https://www.linkedin.com/in/andries-bester/" target="_blank">LinkedIn</a>
    </div>
</div>