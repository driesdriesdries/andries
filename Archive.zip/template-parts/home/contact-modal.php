<div class="modal-window">
    <div class="modal-inner">
    <div class="modal-inner__header">
        <h3>Hello!  :)</h3>
        <span>X</span>
    </div>    
        <?php echo do_shortcode('[contact-form-7 id="7c73b29" title="Contact form 1"]'); ?>
    </div>
</div>